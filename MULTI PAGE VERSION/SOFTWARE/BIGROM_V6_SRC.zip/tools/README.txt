TOOLS

All the programs heare are third-party tools:

- cc65/apple2
ac.jar https://github.com/AppleCommander

- cc65/c64
prg2crt.py http://www.frank-buss.de/c64/prg2crt/index.html

- cc65/gamate
gamate-fixcart.exe https://github.com/cc65/cc65/blob/master/util/gamate/gamate-fixcart.c

- cc65/osic1p
srec_cat.exe http://srecord.sourceforge.net/

- cmoc/coco
file2dsk.exe http://www.colorcomputerarchive.com/coco/Utilities/?fbclid=IwAR2BOfF9KYC1hE8OaBU2vad_Y1iWDCbtX6lvLNIpns7OcpgJlWuqguybH5U

- cmoc/dragon
bin2cas.pl https://www.6809.org.uk/dragon/
File2VDK.exe https://github.com/rolfmichelsen/dragontools

- cmoc/mo5
f2k5.exe  http://pulkomandy.tk/projects/thomson/browser/Thomson/tools/
sapfs.exe http://pulkomandy.tk/projects/thomson/browser/Thomson/tools/

- gcc
libncurses https://www.gnu.org/software/ncurses/

- generic
exomizer.exe https://bitbucket.org/magli143/exomizer/wiki/Home
c1541.exe http://vice-emu.sourceforge.net/

- olivetti_m20
m20 ftp://ftp.groessler.org/pub/chris/olivetti_m20/imgtools/m20floppy-0.61.tar.gz

- z88dk/abc80
bin2bac2.exe
dosgen
doscopy

- z88dk/cpc
nocart/nocart.exe http://www.cpcwiki.eu/index.php/Nocart

- z88dk/oz 
makewzd.exe https://github.com/z88dk/z88dk/blob/master/support/oz/makewzd.c

- z88dk/samcoupe 
pyz80.py https://github.com/simonowen/pyz80

