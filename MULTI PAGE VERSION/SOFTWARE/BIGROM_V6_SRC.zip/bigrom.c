#include "mo5_lib.h"
#include "cmoc.h"
#define menu 18
#define ver 6
const unsigned char *lett="LHSRUVFCPTEXDMNBGI";
const unsigned char*roms[menu]={
		" - Lista roms",
		" - Help",
		" - Seleziona rom",
		" - Avvia rom",
		" - Copia da ram in rom",
		" - Visualizza rom",
		" - Multi copia da seriale in rom",
		" - Copia da seriale in ram",
		" - Copia da seriale in rom",
		" - Copia da ram a seriale",
		" - Cancella rom",
		" - Cancella tutta la rom",
		" - Copia rom in ram",
		" - Leggi memoria",
		" - Scrivi memoria",
		" - Cambia banco di memoria",
		" - Esegui subroutine",
		" - Info"
	};
unsigned char ch;
unsigned char selected=255;
unsigned int int_addr=0;
char strtitle[18];
unsigned int posint=0;
unsigned char menu_pos=1;
void help();

unsigned char presskey()
{
	unsigned char ch=0;
	while(1)
	{
		ch=GETCH();
		if(ch!=0)break;
	}
	return ch;
}
void irq_en()
{
	asm
	{
		ANDCC #$AF
	}
}
void irq_dis()
{
	asm
	{
		ORCC #$50
	}
}
void up()
{
	if(menu_pos<menu-1)
		menu_pos++;
	help();
}
void down()
{
	if(menu_pos!=0)
		menu_pos--;
	help();
}
void sel_menu()
{
	selected=menu_pos;
}
int isempty()
{
	unsigned char* addr=0xa7dd;
	unsigned char romen=*addr;
	romen&=0x1f;
	*addr=romen;
	int emp=0;
	asm
	{	PSHS X,Y,D
		LDY #$0001
		LDX #$B000
LOOP_ISEMPTY
		LDD ,X++
		CMPD #$FFFF
		BNE EXIT_NOTEMPTY
		CMPX #$F000
		BNE LOOP_ISEMPTY
		BRA EXIT_ISEMPTY
EXIT_NOTEMPTY
		LDY #$0000
EXIT_ISEMPTY
		STY emp
		PULS X,Y,D
	}
	*addr=0x30;
	return emp;
}
unsigned int hex2int(char *hex) {
    unsigned int val = 0;
    while (*hex) {
        // get current character then increment
        unsigned char byte = *hex++; 
        // transform hex character to the 4bit equivalent number, using the ascii table indexes
        if (byte >= '0' && byte <= '9') byte = byte - '0';
        else if (byte >= 'a' && byte <='f') byte = byte - 'a' + 10;
        else if (byte >= 'A' && byte <='F') byte = byte - 'A' + 10;    
        // shift 4 to make space for new digit, and add the 4 bits of the new digit 
        val = (val << 4) | (byte & 0xF);
    }
    return val;
}
unsigned char getbank()
{
	unsigned char* addr=0xa7e5;
	return *addr;
}
void setbank(unsigned char nbank)
{
	unsigned char* addr=0xa7e5;
	*addr=nbank & 0x1F;
}

void change_bank()
{
	printf("Il banco attuale=%d\n\rVuoi cambiarlo(S)?\n\r",getbank());
		ch=presskey();
	if(ch=='S')
	{
	printf("numero banco?(0..7)\n\r");
	char* str=readline();
	printf("\n\r");
	unsigned char nbank=(unsigned char)atoi(str);
	if (nbank<0 || nbank>7) 
		printf("numero banco non valido!!!\n\r");
	else 
		setbank(nbank);
	}
	else
		printf("operazione annullata!!!\n\r");
}
void exec()
{
	
	PUTCH(12);
	printf("L'esecuzione passera' all' indirizzo\n\r richiesto. Sei sicuro?(S/N)\n\r");
	ch=presskey();
	if(ch=='S')
	{
	printf("Indirizzo di execuzione (hex): \n\r");
	char* hex_addr=readline();
	if(hex_addr!=NULL)
	{
	int_addr=hex2int(hex_addr);
	asm
	{
		JSR [int_addr]
	}
	}
	}
	else
		printf("Operazione annullata\n\r");

}
void showmem()
{
	
	PUTCH(12);
	printf("Memory Dump.\n\r");
	printf("Indirizzo di partenza (hex): ");
	char* hex_addr=readline();
	if(hex_addr!=NULL)
	{
	int_addr=hex2int(hex_addr);
	char byt_str[9];
	byt_str[8]=0;
	unsigned char* p_addr=(unsigned char*)int_addr;
	do
	{
	for(unsigned char r=0;r<24;r++)
	{	
		printf("%04x",int_addr);
		for(unsigned char c=0;c<8;c++)
		{
			unsigned char byte=*(p_addr++);
			if(byte<32 || byte>127)
				byt_str[c]='.';
			else
				byt_str[c]=byte;
			printf(" %02x",byte);
		}
		int_addr+=8;
		printf(" %s\n\r",byt_str);
		//printf("\n\r");
		ch=GETCH();
		if(ch!=0)break;
	}
	ch=presskey();
	}
	while(ch=='M');
	}
	printf("Uscita\n\r");
}
void editmem()
{
	printf("Edita la memoria: aaaa b1 \"STRING\" b2..\n\r");
	char* hex_addr=readline();
	if(hex_addr!=NULL)
	{
		int par=0;
		int i=0;
		unsigned char* address;
		do{
			if(hex_addr[i]==32||hex_addr[i]==0)
			{
				hex_addr[i++]=0;
				if(par==0)
				{
					unsigned int mod_addr=hex2int(hex_addr);
					address=(unsigned char*)mod_addr;
					par++;
					hex_addr+=i;
					i=0;
					
				}
				else
				{
					if(hex_addr[0]==34&&hex_addr[i-2]==34)
					{
						hex_addr++;
						memcpy(address,hex_addr,i-3);
						address+=(i-3);
						i--;
					}
				else
				{
					unsigned char mod_byte=(unsigned char)hex2int(hex_addr);
					*(address++)=mod_byte;
				
				}
					hex_addr+=i;
					i=0;	
				}
			}
		} while(hex_addr[i++]!=0);
	}
	else
		printf("\n\rIndirizzo non valido!!!");
	printf("\n\r");

}		
void gettitle()
{	

	strcpy(strtitle,"VUOTO            \0");

	if(!isempty())
	{
		unsigned char* addr=0xa7dd;
		unsigned char romen=*addr;
		romen&=0x1f;
		*addr=romen;
			int i;
				memcpy(strtitle,(unsigned char*)0xefe0,17);
				for(i=0;i<17;i++)
				{

					if(strtitle[i]<31||strtitle[i]>127)
					strtitle[i]=' ';
				}
				//strtitle[16]=0;
				*addr=0x30;
	}


}
void help()
{	
	gettitle();
	POKE(0x202B,0x46);
	PUTCH(12);
	printf("Titolo attuale: \n\r");
	POKE(0x202B,0x07);
	POKE(0x202A,2);
	printf("%d-%s",posint,strtitle);;
	POKE(0x202A,0);
	POKE(0x202B,0x46);
	printf("\n\r\n\r");
	for(unsigned char i=0;i<menu;i++)
	{	
		POKE(0x202B,0x06);
		printf("%c",lett[i]);
		if(i!=menu_pos)
			POKE(0x202B,0x46);
		else 
			POKE(0x202B,0x64);
		printf("%s\n\r",roms[i]);
	}
	POKE(0x202B,0x46);
}
void info()
{	
	PUTCH(12);
	printf("BigRom ver. %d\n\r",ver);
	printf("hardware and software by dinoprodest\n\r");
	printf("powered by CMOC compiler\n\r");
	printf("dettagli su github/dinoflorenzi\n\r");
}
void list()
{
	unsigned char* pages=0xffff;
	PUTCH(12);
	for(int i=0;i<16;i++)
	{
		
		*(pages-i)=0x00;
		POKE(0x202B,0x07);
		printf("%2d",i);
		gettitle();
		if(strstr(strtitle,"VUOTO")==0)
			POKE(0x202B,0x70);
		else
			POKE(0x202B,0x20);
		printf("%s|",strtitle);
		*(pages-(i+16))=0x00;
		POKE(0x202B,0x07);
		printf("%2d",i+16);
		gettitle();
		if(strstr(strtitle,"VUOTO")==0)
			POKE(0x202B,0x70);
		else
			POKE(0x202B,0x20);
		printf("%s|",strtitle);
	}
	POKE(0x202B,0x46);	
	unsigned int pos=0xffff-posint;
	POKEW (0x2a5f,pos);
	POKE(pos,0);
	
}
void select()
{
	while(1)
	{
	printf("Seleziona rom.\n\r");
	printf("Quale posizione ? (0..31)");
	char* ppos=readline();
	printf("\n\r");
	posint=atoi(ppos);
	if (posint<32) 
		break;
	else
		printf("immettere una posizione valida!!!\n\r");
	
	}
	unsigned int pos=0xffff-posint;
	POKEW (0x2a5f,pos);
	POKE(pos,0);
}
void selecttitle()
{
	select();
	help();
}
void dumprom()
{
	printf("Copia rom in ram (&H6000-&H9fff).\n\r");
	asm
	{
	PSHS D,X,Y
	ORCC #$50
	LDA $A7DD
	ANDA #$1F
	STA $A7DD
	LDX #$6000
	LDY #$B000
LOOP_DUMPROM
	LDB ,Y+
	STB ,X+
	CMPY #$F000
	BNE LOOP_DUMPROM
	LDA #$30
	STA $A7DD
	PULS D,X,Y
	ANDCC #$AF
	}
		printf("Copiata\n\r");
}
void ram2rom(int par)
{
	printf("Copia ram(&H6000-&H9fff) in rom.\n\r");
	if(par) select();
	if(isempty())
	{
	printf("\n\rSto scrivendo......\n\r");
	asm
	{
	PSHS D,X,Y,U
	ORCC #$50
	LDA $A7DD
	ANDA #$1F
	STA $A7DD
	LDX #$6000
	LDY #$B000
LOOP_UPLOAD
	LDB ,X+
	BSR ENABLE
	STB ,Y+
	LDU #20
LOOP_UPLOAD2
	LEAU -1,U
	CMPU #0
	BNE LOOP_UPLOAD2
	CMPX #$A000
	BNE LOOP_UPLOAD
	LDA #$30
	STA $A7DD
	PULS D,X,Y,U
	BRA EXIT_UPLOAD
ENABLE
	LDA #$AA
	STA $FFE1
	STA $D555
	LDA #$55
	STA $FFE0
	STA $EAAA
	LDA #$A0
	STA $FFE1
	STA $D555
	STA [$2A5F]
	RTS
EXIT_UPLOAD
	}
	printf("Scrittura eseguita\n\r");
	}
	else
		printf("\n\rScrittura interrotta, posizione non vuota\n\r");
}
void serial_tx(unsigned char* buf,unsigned short len )
{
	printf("Copia da ram a seriale.\n\r");
	asm
	{
	PSHS X,Y,D
	LDX buf
	LDY len
	ORCC #$50
	LDA $A7CE
	ANDA #$FB
	STA $A7CE 
	LDA #$80
	STA $A7CC
	LDA $A7CE
	ORA #$04
	STA $A7CE
LOOP_SERIAL_TX2
	CMPY #0
	BEQ EXIT
	LDB #8
	BSR SETLOW_SERIAL_TX
	BSR RIT
	LDA ,X+ 
	LEAY -1,Y
LOOP_SERIAL_TX
	PSHS A
	ANDA #$01
	BEQ LOW
	BSR SETHIGH_SERIAL_TX
	BRA RET
LOW
	BSR SETLOW_SERIAL_TX
RET
	BSR RIT
	PULS A
	LSRA
	DECB
	BNE LOOP_SERIAL_TX
	BSR SETHIGH_SERIAL_TX
	BSR RIT
	BRA LOOP_SERIAL_TX2
SETHIGH_SERIAL_TX
	LDA #$FF
	STA $A7CC
	RTS
SETLOW_SERIAL_TX
	LDA #$00
	STA $A7CC
	RTS
RIT
	LDA #10
RITLOOP_SERIAL_TX
	DECA
	BNE RITLOOP_SERIAL_TX
	RTS
EXIT
	ANDCC #$AF
	PULS X,Y,D
	}
	printf("Trasmissione eseguita\n\r");
}
int serial_rx()
{
	int res=0;
	printf("Copia da seriale in ram.\n\r");
	asm
	{
	PSHS X,Y,D
	ORCC #$50
	LDX #$6000
	LDY #$FFFF
	LDB #5
LOOP_SERIAL_RX
	LDA $A7CC     
	ANDA #$40
	BEQ EXIT_SERIAL_RX
	LEAY -1,Y
	CMPY #0
	BNE LOOP_SERIAL_RX
	LDY #$FFFF
	DECB
	BNE LOOP_SERIAL_RX
	BRA EXIT_SERIAL2_RX
EXIT_SERIAL_RX
	LDA #22
	LDB #8
	STD res
RIT_SERIAL_RX
	DECA             
	BNE RIT_SERIAL_RX         
	LSR ,X       
	LDA $A7CC   
	ANDA #$40 
	BEQ SETLOW_SERIAL_RX
	LDA ,X
	ORA #$80
	BRA SETHIGH_SERIAL_RX
SETLOW_SERIAL_RX
	LDA ,X
	ANDA #$7F
	NOP
SETHIGH_SERIAL_RX
	STA ,X
	LDA #14
	DECB
	BNE RIT_SERIAL_RX
RIT_SERIAL_RX2
	DECA
	BNE RIT_SERIAL_RX2
	LDA #22
	LEAX 1,X
	LDY #$FFFF
	LDB #1
	BRA LOOP_SERIAL_RX
EXIT_SERIAL2_RX
	ANDCC #$AF
	PULS X,Y,D
	}
	if(res!=0)
	{
		printf("Scrittura eseguita\n\r");
		res=1;
	}
	else
		printf("Timeout!!!!\n\r");
	return res;
}
void erasesec()
{
	printf("Cancella singola rom.\n\r");
	printf("Sei sicuro?(S/N)\n\r");
	ch=presskey();
	if(ch=='S')
	{
	select();
	asm
	{
	PSHS D,X,Y,CC
	ORCC #$50
	LDA $A7DD
	ANDA #$1F
	STA $A7DD
	LDX #$B000
LOOP_ERASESEC
	LDY #2500
RIT_ERASESEC
	LEAY -1,Y
	CMPY #0
	BNE RIT_ERASESEC
	LDB #$AA
	STB $FFE1
	STB $D555
	LDB #$55
	STB $FFE0
	STB $EAAA
	LDB #$80
	STB $FFE1
	STB $D555
	LDB #$AA
	STB $D555
	LDB #$55
	STB $FFE0
	STB $EAAA
	LDB #$30
	STB [$2A5F]
	STB ,X
	LEAX $1000,X
	CMPX #$F000
	BNE LOOP_ERASESEC
	LDA #$30
	STA $A7DD
	PULS D,X,Y,CC
	}
	printf("\n\rRom cancellata\n\r");
	}
	if(ch=='N')
		printf("Operazione annullata\n\r");
}
void showrom()
{
	PUTCH(12);
	SWITCH_COLOR_BANK_OFF();
	asm
	{
	PSHS D,X,Y,CC
	ORCC #$50
	LDA $A7DD
	ANDA #$1F
	STA $A7DD
	LDX #$0000
	LDY #$B000
LOOP_SHOWROOM
	LDB ,Y+
	STB ,X+
	CMPY #$D000
	BNE LOOP_SHOWROOM
PRESSKEY
	SWI
	.BYTE 10
	CMPB #0
	BEQ PRESSKEY
	LDX #$0000
LOOP_SHOWROOM2
	LDB ,Y+
	STB ,X+
	CMPY #$F000
	BNE LOOP_SHOWROOM2
	LDA #$30
	STA $A7DD
	PULS D,X,Y,CC
	}
}
void eraseall()
{
	PUTCH(12);
	printf("Cancella tutta la rom.\n\r");
	printf("Sei sicuro?(S/N)\n\r");
	ch=presskey();
	if(ch=='S')
	{
	asm
	{
	PSHS D,X,Y
	ORCC #$50
	LDA $A7DD
	ANDA #$1F
	STA $A7DD
	LDA #$AA
	STA $FFE1
	STA $D555
	LDA #$55
	STA $FFE0
	STA $EAAA
	LDA #$80
	STA $FFE1
	STA $D555
	LDA #$AA
	STA $D555
	LDA #$55
	STA $FFE0
	STA $EAAA
	LDA #$10
	STA $FFFE1
	STA $D555
	LDA #$30
	STA $A7DD
	PULS D,X,Y
	}
		printf("Rom cancellata\n\r");
	}
	if(ch=='N')
	{
		printf("Operazione annullata\n\r");
	}
}
void runrom()
{
	//select();
	if(!isempty())
	{
	asm
	{
		LDA $A7DD
		ANDA #$1F
		STA $A7DD
		JMP [0xEFFE]
	}
	}
	else
		printf("\n\rposizione vuota!!!!!\n\r");
}
void ser2rom()
{
	serial_rx();
	printf("\n\r");
	ram2rom(1);

}
void multiupload()
{
	unsigned char tx=2;
	unsigned char* pages=0xffff;
	unsigned int addr=0xffff;
	PUTCH(12);
	printf("Multicopia da seriale 9600 baud a rom.\n\r");
	printf("Avvire SerialRom.exe su PC e premere S per continuare.\n\r");
	ch=presskey();
	if(ch=='S')
	{
	for(int i=0;i<32;i++)
	{
		*(pages-i)=0x00;
		printf("%d ",i);
		gettitle();
		printf("%s\n\r",strtitle);	
		if(isempty())
		{
		serial_tx(&tx,1);
		if(serial_rx()==1)
			{
			POKEW (0x2a5f,addr-i);
			ram2rom(0);
			gettitle();
			printf("Caricato: %s",strtitle);
			}
			else
			{
				printf("Comunicazione interrotta!!!!\n\r");
				break;
			}
		}
		printf("\n\r\n\r");	
		
	}
	printf("OPerazione terminata.\n\r");
	}
	else
		printf("Operazione annullata\n\r");
}
int main()
{
	PUTCH(17);
	help();

	while(1){
		if (selected==255)
		{
			ch=GETCH();
			for(unsigned char i=0;i<menu;i++)
			{
			if(lett[i]==ch)
				menu_pos=i;
			}
			
		}
		else
		{
			selected=255;
			ch=lett[menu_pos];
		}
		switch(ch)
		{
			case 30:
			PUTCH(12);
			break;
			case 10:
			up();
			break;
			case 11:
			down();
			break;
			case 13:
			sel_menu();
			break;
			case 'F':
			multiupload();
			break;
			case 'I':
			info();
			break;
			case 'R':
			runrom();
			break;
			case 'T':
			unsigned char* addr=0x6000;
			serial_tx(addr,0x4000);
			break;
			case 'H':
			help();
			break;
			case 'L':
			list();
			break;
			case 'S':
			selecttitle();
			break;
			case 'P':
			ser2rom();
			break;
			case 'U':
			ram2rom(1);
			break;
			case 'C':
			serial_rx();
			break;
			case 'E':
			erasesec();
			break;
			case 'X':
			eraseall();
			break;
			case 'V':
			showrom();
			break;
			case 'D':
			dumprom();
			break;
			case 'M':
			showmem();
			break;
			case 'N':
			editmem();
			break;
			case 'B':
			change_bank();
			break;
			case 'G':
			exec();
			break;
		}
	};

	return 0;
}
